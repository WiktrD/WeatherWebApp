import App from './app';
import IndexController from "./controlers/IndexController";

const app: App = new App([
    new IndexController()
]);

app.listen();