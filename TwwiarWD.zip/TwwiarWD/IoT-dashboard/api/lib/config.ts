export const config = {
    port: process.env.PORT || 3100
};